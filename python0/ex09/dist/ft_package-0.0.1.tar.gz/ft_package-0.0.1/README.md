# Example Of Pandas Columns

- this is sample of pandas columns
